let allRecipes = [];
    document.getElementById('image').addEventListener('change', function (e) {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function (event) {
          document.getElementById('previewArea').innerHTML = `<img src="${event.target.result}" alt="Preview" />`;
        };
        reader.readAsDataURL(file);
      }
    });
  
    function format(text) {
      return text.replace(/&/g, "&amp;")
                 .replace(/</g, "&lt;")
                 .replace(/>/g, "&gt;");
    }
  
    document.getElementById('textFile').addEventListener('change', function (e) {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = function (event) {
          document.getElementById('previewArea').innerHTML += `<pre>${format(event.target.result)}</pre>`;
        };
        reader.readAsText(file);
      }
    });
  

    document.getElementById('uploadForm').addEventListener('submit', function (e) {
      e.preventDefault();
      const titleField = document.getElementById('title');
      const ingredientsField = document.getElementById('ingredients');
      const instructionsField = document.getElementById('instructions');
      const imageField = document.getElementById('image');
      const textFileField = document.getElementById('textFile');
      const previewArea = document.getElementById('previewArea');
  
      const title = titleField.value.trim();
      const ingredients = ingredientsField.value.split(',').map(i => i.trim()).filter(i => i);
      const instructions = instructionsField.value;
      const imageFile = imageField.files[0];
      const textFile = textFileField.files[0];
  
      if (!instructions && !textFile) {
        alert('Please enter instructions or upload a text file.');
        return;
      }
  
      const formData = new FormData();
      formData.append('title', title);
      formData.append('ingredients', JSON.stringify(ingredients));
      formData.append('instructions', instructions);
      if (imageFile) formData.append('image', imageFile);
      if (textFile) formData.append('textFile', textFile);
  
      fetch('php/saveRecipe.php', {
        method: 'POST',
        body: formData
      })
      .then(res => res.json())
      .then(data => {
        alert(data.message);
        if (data.success) {
          loadRecipes();
          titleField.value = '';
          ingredientsField.value = '';
          instructionsField.value = '';
          imageField.value = '';
          textFileField.value = '';
          previewArea.innerHTML = '';
        }
      });
    });
  
    function isValidRecipe(r) {
      return r.title && r.ingredients && typeof r.instructions === 'string';
    }
  
    function loadRecipes() {
      fetch('php/loadRecipes.php')
        .then(res => res.json())
        .then(recipes => {
          allRecipes = recipes.filter(isValidRecipe);
          renderRecipes(allRecipes);
        });
    }
  
    function renderRecipes(recipes) {
      const container = document.getElementById('recipeList');
      container.innerHTML = '';
      recipes.forEach(recipe => {
        const div = document.createElement('div');
        div.classList.add('recipe');
  
        const title = document.createElement('h3');
        title.textContent = recipe.title;
  
        const content = document.createElement('div');
        content.classList.add('recipe-content');
        content.innerHTML = `
          <p><strong>Ingredients:</strong> ${recipe.ingredients.join(', ')}</p>
          <p><strong>Instructions:</strong><br>${recipe.instructions.replace(/\n/g, "<br>")}</p>
          ${recipe.image ? `<img src="${recipe.image}" alt="Recipe Image" />` : ''}
        `;
  
        title.addEventListener('click', () => {
          content.style.display = content.style.display === 'none' ? 'block' : 'none';
        });
  
        div.appendChild(title);
        div.appendChild(content);
        container.appendChild(div);
      });
    }
  
    document.getElementById('searchButton').addEventListener('click', () => {
      const keyword = document.getElementById('searchInput').value.toLowerCase();
      const filtered = allRecipes.filter(r => r.title.toLowerCase().includes(keyword));
      renderRecipes(filtered);
    });
    document.getElementById('resetButton').addEventListener('click', () => {
      document.getElementById('searchInput').value = '';
      renderRecipes(allRecipes);
    });
    window.addEventListener('DOMContentLoaded', loadRecipes);